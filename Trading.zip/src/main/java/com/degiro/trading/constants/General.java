package com.degiro.trading.constants;

public enum General {

    INSTANCE;

    public static final String END_OF_INPUT = "0";
    public static final String ZERO_ITEMS_TO_BUY = "0";
    public static final int MAX_NUMBER_OF_FLUTS_TO_SHOW = 10;
}
